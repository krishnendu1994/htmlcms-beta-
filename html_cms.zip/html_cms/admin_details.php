
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php include('helper/url_helper.php') ?>
<!DOCTYPE HTML>
<html>
<head>
<title>Minimal an Admin Panel Category Flat Bootstrap Responsive Website Template | Signup :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="<?php echo $base_url; ?>assets/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="<?php echo $base_url; ?>assets/css/style.css" rel='stylesheet' type='text/css' />
<link href="<?php echo $base_url; ?>assets/css/font-awesome.css" rel="stylesheet"> 
<script src="<?php echo $base_url; ?>assets/js/jquery.min.js"> </script>
<script src="<?php echo $base_url; ?>assets/js/blockui.js"> </script>
<script src="<?php echo $base_url; ?>assets/js/bootstrap.min.js"> </script>
</head>
<body>
	<div class="login">
		<h1><a href="index.html">Fill Up Admin Credentials </a></h1>
		<div class="login-bottom">
			<h2 style="text-align: center;">Give Admin Details</h2>
			<div class="col-md-12">
				<div class="login-mail">
					<input type="text" placeholder="Admin User" id="admin_user"  required="">
					
				</div>
				<div class="login-mail">
					<input type="text" placeholder="Admin Password" id="admin_pass" required="">
					
				</div>
				
				 
	
			</div>
			<div class="col-md-3 login-do" style="text-align: center;">&nbsp;</div>
			<div class="col-md-6 login-do" style="text-align: center;">
				<label class="hvr-shutter-in-horizontal login-sub">
					<input type="button" class="button_login" value="Submit">
					</label>
					
			</div>
			<div class="col-md-3 login-do" style="text-align: center;">&nbsp;</div>
			<div class="clearfix"> </div>
		</div>
	</div>
	<script type="text/javascript">
		 $(document).ready(function() {

          $('.button_login').click(function(){
           $.blockUI ({
            message: 'Please Wait';
           });
            setTimeout($.unblockUI,2000);
           alert('hjgj');
         });
          });
	</script>
		<!---->
<div class="copy-right">
            <p> &copy; 2017 Htmlcms. All Rights Reserved | Design & Developed by <a href="#" target="_blank">Krishnendu Paul</a> </p>	    </div>
	  
<!---->
<!--scrolling js-->
	<script src="<?php echo $base_url; ?>assets/js/jquery.nicescroll.js"></script>
	<script src="<?php echo $base_url; ?>assets/js/scripts.js"></script>
	<!--//scrolling js-->
	<script type="text/javascript">
    //     $(document).ready(function() {

    //       $('#submit').click(function(){
    //        $.blockUI ({
    //         message: 'Please Wait';
    //        });
    //         setTimeout($.unblockUI,2000);
    //         var db_host=$('#db_host').val();
    //         var db_email=$('#db_email').val();
    //         var db_user=$('#db_user').val();
    //         var db_pass=$('#db_pass').val();
    //       $.ajax({
    //   type:"post",
    //   url:"<?php echo $base_url; ?>index.php/install_cont/db_install",
    //   data:'db_host='+db_host+'&db_email='+db_email+'&db_user='+db_user+'&db_pass='+db_pass,
    //   success:function(y)
    //   {
    //    alert('Password Has Bean successfully Send To Your Email');
    //   }
    // });
    //       // alert('hjgj');
    //       });
    //       });
     $(document).ready(function() {

          $('.button_login').click(function(){
           
           
           var admin_user=$('#admin_user').val();
            var admin_pass=$('#admin_pass').val();
           

          $.ajax({
      type:"post",
      url:"<?php echo $base_url; ?>admin_cont.php",
      data:'admin_user='+admin_user+'&admin_pass='+admin_pass,
      success:function(y)
      {
        if(y=='done')
        {
          window.location='congratulation.php';
        }
      
      }
    });
           });
          });
        </script>
</body>
</html>

