<?php
 $page_id=$_GET['page_id'];


 ?>

 <?php include('config.php'); 
include('main/helper_header.php');
?>



<?php
include('main/helper_footer.php');  
 $sql_chk="select * from theme where status='active'";
   $query_chk=$mysqli->query($sql_chk);
   $row_chk=$query_chk->fetch_array();
   $theme_id=$row_chk['id'];

    $sql_chk_th="select * from theme where id='$theme_id'";
   $query_chk_th=$mysqli->query($sql_chk_th);
   $row_chk_th=$query_chk_th->fetch_array();
   $theme_name=$row_chk_th['theme_name'];

 $theme_page_id=$_GET['page_id'];


 $path = dirname(__FILE__).'/';
   $sql_theme_index_body_chk="select * from theme_body where theme_id='$theme_id' and id='$theme_page_id'";
   $query_theme_index_body_chk=$mysqli->query($sql_theme_index_body_chk);
   while($row_theme_index_body_chk=$query_theme_index_body_chk->fetch_array())
   {
   echo	 $header.$str=base64_decode($row_theme_index_body_chk['page_content']).$footer;
   	 


   }

  
 
 ?>

<!-- for only these theme -->
<script type="text/javascript">
  $(document).ready(function () {
    //Hover Menu in Header
    $('ul.nav li.dropdown').hover(function () {
        $(this).find('.mega-dropdown-menu').stop(true, true).delay(200).fadeIn(200);
        $('.darkness').stop(true, true).fadeIn();
    }, function () {
        $(this).find('.mega-dropdown-menu').stop(true, true).delay(200).fadeOut(200);
         $('.darkness').stop(true, true).delay(200).fadeOut();
    });
});
</script>
<!-- for only these theme -->

  <script type="text/javascript">
var ghfhg='<?php echo $theme_name; ?>';
      var imgTags = $('img').each(function() {
                var urlRelative = $(this).attr("src");
                var urlAbsolute = 'themes/'+ghfhg+'/'  + urlRelative;
                 if (urlRelative.indexOf('../themes/'+'<?php echo $theme_name; ?>'+'/') >= 0)
                {
                 urlRelative=urlRelative.replace("../", "");
                  var urlAbsolute =urlRelative
                }

                //$(this).attr("src").replace(urlRelative, urlAbsolute); // problem here
                $(this).attr("src", urlAbsolute)
            });

//  var imgTags = $('ul li a').each(function() {
//                 var urlRelative_ul = $(this).attr("href");

// var output = urlRelative_ul.substr(0, urlRelative_ul.lastIndexOf('.')) || urlRelative_ul;
// <?php
//  $sql_chk_th="select * from theme_page where theme_id='$theme_id' and page_name=''";
//    $query_chk_th=$mysqli->query($sql_chk_th);
//  ?>
//                 var urlAbsolute_ul = 'themes/'+ghfhg+'/'  + urlRelative_ul;
               
//                 //$(this).attr("src").replace(urlRelative, urlAbsolute); // problem here
//                 $(this).attr("href", urlAbsolute_ul)
//             });



       var imgTags1 = $('div').each(function() {
        if ($(this).css('background-image') != 'none') {
   var urlRelative1 = $(this).css('background-image');
                var urlAbsolute2 = 'themes/'+ghfhg;
                //$(this).attr("src").replace(urlRelative, urlAbsolute); // problem here
                urlRelative1 = urlRelative1.replace('url(','').replace(')','').replace(/\"/gi, "");
      
   var l = window.location;
var base_url = l.protocol + "//" + l.host + "/" + l.pathname.split('/')[1];    

var yuyyyyy=urlRelative1;
// alert(urlRelative1);

 yuyyyyy='url('+yuyyyyy+')'
               // var yuyu="background-image:url("+urlAbsolute1+")";
                $(this).css("background-image", yuyyyyy)
}
               
            });
</script>
<script type="text/javascript">
 $('form').each(function() {
    var id=this.id;
  
    $(this).append("<input type='hidden' name='form_id' value='"+id+"'>");
    //alert(id);
    $(this).attr('action','htmlcf/htmlcf.php');
    $(this).attr('method','post');
    // $(this).submit();
    $(this).find('input, select, textarea').each(function(key){
           // alert(key + ': ' + jQuery(this).val());
            var attr = $(this).attr('name');
  
// For some browsers, `attr` is undefined; for others,
// `attr` is false.  Check for both.
if ( attr == undefined) {

   $(this).attr('name','fm'+key)
}
        });
    
  })
</script>
<script type="text/javascript">
// //    $('form').children('input, select, textarea').each(function(key){
// //             // alert(key + ': ' + jQuery(this).val());
// //           //  var attr = $(this).attr('name');
// //  alert();
// // // For some browsers, `attr` is undefined; for others,
// // // `attr` is false.  Check for both.
// // // if (typeof attr !== typeof undefined && attr !== false) {

// // //    $(this).attr('name','fm'+key)
// // // }
// //         });
// $(function(){
//     // $("input#check").click(function(){
//         jQuery('form input, select, textarea').each(function(key){
//             alert(key + ': ' + jQuery(this).val());
//         });
//     //});
// });
</script>
 