
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php include('helper/url_helper.php') ?>
<!DOCTYPE HTML>
<html>
<head>
<title>Minimal an Admin Panel Category Flat Bootstrap Responsive Website Template | Signup :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="<?php echo $base_url; ?>assets/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="<?php echo $base_url; ?>assets/css/style.css" rel='stylesheet' type='text/css' />
<link href="<?php echo $base_url; ?>assets/css/font-awesome.css" rel="stylesheet"> 
<script src="<?php echo $base_url; ?>assets/js/jquery.min.js"> </script>
<script src="<?php echo $base_url; ?>assets/js/blockui.js"> </script>
<script src="<?php echo $base_url; ?>assets/js/bootstrap.min.js"> </script>
<style type="text/css">
  .text-sub input[type="submit"] {
    background-color: #D95459;
    font-size: 1em;
    color: #fff;
    border: none;
    outline: none;
    padding: 0.5em 1.5em;
    border-radius: 4px;
}
</style>
</head>
<body>
	<div class="grid_3 grid_5 ">
     <h3 class="head-top" style="text-align: center; color: #d95459;
    text-decoration: none;">Congratulation You Have Successfully Installed Htmlcms</h3>
      <div class="bs-example2">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
         
          <h2 class="modal-title" style="text-align: center;">Upload Your Html File(.zip Only)</h2>
        </div>
        <div class="modal-body">
          <div class="post-at">
          <form class="text-sub" action="html_upload.php" enctype="multipart/form-data" method="post" style="float: none;">
            <ul class="icon" style="float: left;">
              
              
              <div class="post-file">
              <i class="fa fa-file-archive-o" aria-hidden="true"></i>
              <input id="input-1" name="zip_file" type="file"  class="">
              </div>
              
              
              <script>
              $(document).on('ready', function() {
                $("#input-1").fileinput({showCaption: false});
              });
              </script>
             
            </ul>
            
              <input type="submit" value="Upload" style="float: right;">
            </form>
            <div class="clearfix"> </div>
          </div>
        </div>
        <div class="modal-footer">
          
          &nbsp;
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
     </div>

         </div>
	
		<!---->
<div class="copy-right">
            <p> &copy; 2017 Htmlcms. All Rights Reserved | Design & Developed by <a href="#" target="_blank">Krishnendu Paul</a> </p>	    </div>
	  
<!---->
<!--scrolling js-->
	<script src="<?php echo $base_url; ?>assets/js/jquery.nicescroll.js"></script>
	<script src="<?php echo $base_url; ?>assets/js/scripts.js"></script>
	<!--//scrolling js-->

</body>
</html>

