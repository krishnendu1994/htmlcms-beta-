<?php

include('config.php');
 $admin_user=$_POST['admin_user'];
		  	 $admin_pass=$_POST['admin_pass'];
             $password=$admin_pass;
             include('helper/encrypt_helper.php');
             $pass_en=$encrypt;
              

		  	$sql="insert into `admin`(user_name,password) values('$admin_user','$pass_en')";
    $query=$mysqli->query($sql);
		if($query)
        {
            echo 'done';
        }  	

?>