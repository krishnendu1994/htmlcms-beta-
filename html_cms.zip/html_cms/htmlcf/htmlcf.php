<?php

include('../config.php');
 $nows = date('Y-m-d H:i:s');
if(isset($_POST))
{
	//print_r($_POST);
	$form_id=$_POST['form_id'];
	$submit_p=$_POST;
	foreach ($submit_p as $key => $value) {
		$key=$key+1;
		if($value!=$form_id)
		{
			$vggg[]=$value;
		}
		

		
	}
	$vgggggg=implode('**', $vggg);
	$sql="insert into htmlcf(form_id,value,dm)values('$form_id','$vgggggg','$nows')";
		$submit_query=$mysqli->query($sql);
	if($submit_query)
	{
if (filter_var($value, FILTER_VALIDATE_EMAIL)) {
   $fetch_html_cf_sql="select * from htmlcf_setting";
                    $query_chk_th=$mysqli->query($fetch_html_cf_sql);
$row_chk_th=$query_chk_th->fetch_array();

$template=$row_chk_th['template'];
$img=$row_chk_th['logo'];
	$title=$row_chk_th['title'];
	$content=$row_chk_th['content'];
	$footer=$row_chk_th['footer'];
	$reply_mail=$row_chk_th['reply_mail'];
if($template=='mail1.html')
{
	
	
	$message="<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css'>
    
 <center>   <div style='width:33%; margin-left:auto; margin-right:auto; padding: 15px; margin-bottom: 20px; border: 1px solid transparent; border-radius: 4px; background-color:#ccc;'>

        <a href='#'>
    <img src='$img'/>
        </a>

        <div style='font-family: Arial; border-color: #bce8f1;'>

<div style='vertical-align:middle; text-align:center;'>
<h2>
$title
</h2>
    
    <p style='color:#A9A9A9; text-align:left;' >
        Congratulations!
            </p>

  ".htmlspecialchars_decode($content)." 

    
       

    
    
            <hr/>
            
   $footer

</div>
  </div>
</div>
</center>
";
}
if($template=='mail2.html')
{
	$message="

<body bgcolor='#E1E1E1' leftmargin='0' marginwidth='0' topmargin='0' marginheight='0' offset='0'>

 
  <center style='background-color:#E1E1E1;'>
    <table border='0' cellpadding='0' cellspacing='0' height='100%' width='100%' id='bodyTable' style='table-layout: fixed;max-width:100% !important;width: 100% !important;min-width: 100% !important;'>
      <tr>
        <td align='center' valign='top' id='bodyCell'>

          <table bgcolor='#E1E1E1' border='0' cellpadding='0' cellspacing='0' width='500' id='emailHeader'>

            <!-- HEADER ROW // -->
            <tr>
              <td align='center' valign='top'>
                <!-- CENTERING TABLE // -->
                <table border='0' cellpadding='0' cellspacing='0' width='100%'>
                  <tr>
                    <td align='center' valign='top'>
                      <!-- FLEXIBLE CONTAINER // -->
                      <table border='0' cellpadding='10' cellspacing='0' width='500' class='flexibleContainer'>
                        <tr>
                          <td valign='top' width='500' class='flexibleContainerCell'>

                            <!-- CONTENT TABLE // -->
                            <table align='left' border='0' cellpadding='0' cellspacing='0' width='100%'>
                              <tr>
                               
                                <td align='left' valign='middle' id='invisibleIntroduction' class='flexibleContainerBox' style='display:none !important; mso-hide:all;'>
                                  <table border='0' cellpadding='0' cellspacing='0' width='100%' style='max-width:100%;'>
                                    <tr>
                                      <td align='left' class='textContent'>
                                       
                                      </td>
                                    </tr>
                                  </table>
                                </td>
                                <td align='right' valign='middle' class='flexibleContainerBox'>
                                  <table border='0' cellpadding='0' cellspacing='0' width='100%' style='max-width:100%;'>
                                    <tr>
                                      <td align='left' class='textContent'>
                                        <!-- CONTENT // -->
                                        <!-- <div style='font-family:Helvetica,Arial,sans-serif;font-size:13px;color:#828282;text-align:center;line-height:120%;'>
                                          If you can't see this message, <a href='#' target='_blank' style='text-decoration:none;border-bottom:1px solid #828282;color:#828282;'><span style='color:#828282;'>view&nbsp;it&nbsp;in&nbsp;your&nbsp;browser</span></a>.
                                        </div> -->
                                      </td>
                                    </tr>
                                  </table>
                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                      <!-- // FLEXIBLE CONTAINER -->
                    </td>
                  </tr>
                </table>
                <!-- // CENTERING TABLE -->
              </td>
            </tr>
            <!-- // END -->

          </table>
          <!-- // END -->

          <!-- EMAIL BODY // -->
          <!--
							The table 'emailBody' is the email's container.
							Its width can be set to 100% for a color band
							that spans the width of the page.
						-->
          <table bgcolor='#FFFFFF' border='0' cellpadding='0' cellspacing='0' width='500' id='emailBody'>

            <!-- MODULE ROW // -->
            <!--
								To move or duplicate any of the design patterns
								in this email, simply move or copy the entire
								MODULE ROW section for each content block.
							-->
            <tr>
              <td align='center' valign='top'>
                <!-- CENTERING TABLE // -->
                <!--
										The centering table keeps the content
										tables centered in the emailBody table,
										in case its width is set to 100%.
									-->
                <table border='0' cellpadding='0' cellspacing='0' width='100%' style='color:#FFFFFF;' bgcolor='#3498db'>
                  <tr>
                    <td align='center' valign='top'>
                      <!-- FLEXIBLE CONTAINER // -->
                      <!--
													The flexible container has a set width
													that gets overridden by the media query.
													Most content tables within can then be
													given 100% widths.
												-->
                      <table border='0' cellpadding='0' cellspacing='0' width='500' class='flexibleContainer'>
                        <tr>
                          <td align='center' valign='top' width='500' class='flexibleContainerCell'>

                            <!-- CONTENT TABLE // -->
                            <!--
															The content table is the first element
																that's entirely separate from the structural
																framework of the email.
															-->
                            <table border='0' cellpadding='30' cellspacing='0' width='100%'>
                              <tr>
                                <td align='center' valign='top' class='textContent'>
                                  <h1 style='color:#FFFFFF;line-height:100%;font-family:Helvetica,Arial,sans-serif;font-size:35px;font-weight:normal;margin-bottom:5px;text-align:center;'> <img src='$img'/></h1>
                                  <h2 style='text-align:center;font-weight:normal;font-family:Helvetica,Arial,sans-serif;font-size:23px;margin-bottom:10px;color:#205478;line-height:135%;'>$title</h2>
                                  <div style='text-align:center;font-family:Helvetica,Arial,sans-serif;font-size:15px;margin-bottom:0;color:#FFFFFF;line-height:135%;'></div>
                                </td>
                              </tr>
                            </table>
                            <!-- // CONTENT TABLE -->

                          </td>
                        </tr>
                      </table>
                      <!-- // FLEXIBLE CONTAINER -->
                    </td>
                  </tr>
                </table>
                <!-- // CENTERING TABLE -->
              </td>
            </tr>
            <!-- // MODULE ROW -->


            <!-- MODULE ROW // -->
            <!--  The 'mc:hideable' is a feature for MailChimp which allows
								you to disable certain row. It works perfectly for our row structure.
								http://kb.mailchimp.com/article/template-language-creating-editable-content-areas/
							-->
            <tr mc:hideable>
              <td align='center' valign='top'>
                <!-- CENTERING TABLE // -->
                <table border='0' cellpadding='0' cellspacing='0' width='100%'>
                  <tr>
                    <td align='center' valign='top'>
                      <!-- FLEXIBLE CONTAINER // -->
                      <table border='0' cellpadding='30' cellspacing='0' width='500' class='flexibleContainer'>
                        <tr>
                          <td valign='top' width='500' class='flexibleContainerCell'>

                            <!-- CONTENT TABLE // -->
                            <table align='left' border='0' cellpadding='0' cellspacing='0' width='100%'>
                              <tr>
                                <td align='left' valign='top' class='flexibleContainerBox'>
                                  <table border='0' cellpadding='0' cellspacing='0' width='100%' style='max-width: 100%;'>
                                    <tr>
                                      <td align='left' class='textContent'>
                                        '.htmlspecialchars_decode($content).' 
                                      </td>
                                    </tr>
                                  </table>
                                </td>
                               <!--  <td align='right' valign='middle' class='flexibleContainerBox'>
                                  <table class='flexibleContainerBoxNext' border='0' cellpadding='0' cellspacing='0' width='210' style='max-width: 100%;'>
                                    <tr>
                                      <td align='left' class='textContent'>
                                        <h3 style='color:#5F5F5F;line-height:125%;font-family:Helvetica,Arial,sans-serif;font-size:20px;font-weight:normal;margin-top:0;margin-bottom:3px;text-align:left;'>Right Column</h3>
                                        <div style='text-align:left;font-family:Helvetica,Arial,sans-serif;font-size:15px;margin-bottom:0;color:#5F5F5F;line-height:135%;'>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis.</div>
                                      </td>
                                    </tr>
                                  </table>
                                </td> -->
                              </tr>
                            </table>
                            <!-- // CONTENT TABLE -->

                          </td>
                        </tr>
                      </table>
                      <!-- // FLEXIBLE CONTAINER -->
                    </td>
                  </tr>
                </table>
                <!-- // CENTERING TABLE -->
              </td>
            </tr>
            <!-- // MODULE ROW -->


            <!-- MODULE ROW // -->
            <tr>
              <td align='center' valign='top'>
                <!-- CENTERING TABLE // -->
                <table border='0' cellpadding='0' cellspacing='0' width='100%'>
                  <tr style='padding-top:0;'>
                    <td align='center' valign='top'>
                      <!-- FLEXIBLE CONTAINER // -->
                      <table border='0' cellpadding='30' cellspacing='0' width='500' class='flexibleContainer'>
                        <tr>
                          <td style='padding-top:0;' align='center' valign='top' width='500' class='flexibleContainerCell'>

                            <!-- CONTENT TABLE // -->
                            
                            <!-- // CONTENT TABLE -->

                          </td>
                        </tr>
                      </table>
                      <!-- // FLEXIBLE CONTAINER -->
                    </td>
                  </tr>
                </table>
                <!-- // CENTERING TABLE -->
              </td>
            </tr>
            <!-- // MODULE ROW -->



          <!-- EMAIL FOOTER // -->
          <!--
							The table 'emailBody' is the email's container.
							Its width can be set to 100% for a color band
							that spans the width of the page.
						-->
          <table bgcolor='#E1E1E1' border='0' cellpadding='0' cellspacing='0' width='500' id='emailFooter'>

            <!-- FOOTER ROW // -->
            <!--
								To move or duplicate any of the design patterns
								in this email, simply move or copy the entire
								MODULE ROW section for each content block.
							-->
            <tr>
              <td align='center' valign='top'>
                <!-- CENTERING TABLE // -->
                <table border='0' cellpadding='0' cellspacing='0' width='100%'>
                  <tr>
                    <td align='center' valign='top'>
                      <!-- FLEXIBLE CONTAINER // -->
                      <table border='0' cellpadding='0' cellspacing='0' width='500' class='flexibleContainer'>
                        <tr>
                          <td align='center' valign='top' width='500' class='flexibleContainerCell'>
                            <table border='0' cellpadding='30' cellspacing='0' width='100%'>
                              <tr>
                                <td valign='top' bgcolor='#E1E1E1'>

                                  <div style='font-family:Helvetica,Arial,sans-serif;font-size:13px;color:#828282;text-align:center;line-height:120%;'>
                                    <div> $footer</div>
                                    
                                  </div>

                                </td>
                              </tr>
                            </table>
                          </td>
                        </tr>
                      </table>
                      <!-- // FLEXIBLE CONTAINER -->
                    </td>
                  </tr>
                </table>
                <!-- // CENTERING TABLE -->
              </td>
            </tr>

          </table>
          <!-- // END -->

        </td>
      </tr>
    </table>
  </center>
";
}
if($template=='mail3.html')
{
	$message="<!-- See the settings for some head CSS styles -->
<center><table class='email' 
       width='50%'
       border= 0;
       cellspacing=0;
       cellpadding='20' 
       style='border-bottom-width: 10px;
              border-bottom-style: solid;
              border-bottom-color: #ff665e; width: 50%;
    text-align: center;'>
  
  <tr>
    <td class='header' 
       style='background-color: #ff665e;'>
      
      <table border='0' 
             style='color: #fff; 
                    width: 600px; 
                    margin: 0 auto; 
                    font-family: Arial, Helvetica, sans-serif;' 
            cellspacing='0'  width='600'>
          <tr>
            <td colspan='2'>
              <p><img src='$img'/></p>
              <h1>$title</h1>
            </td>
          </tr>
        </table>
      
    </td>
  </tr>
 <tr>
    <td class='content' 
       style='background-color: #eee;'>
      
    <table border='0' 
           style='background-color:#fff; 
                  color: #444; 
                  width: 600px; 
                  margin: 0 auto; 
                  border-bottom-width: 1px;
                  border-bottom-style: solid;
                  border-bottom-color: #ddd;
                  font-family: Arial, Helvetica, sans-serif;' 
           cellpadding='30' cellspacing='0'  width='600'>
       <tr>
         <td colspan='2'>
           '.htmlspecialchars_decode($content).' 
            

         </td>
       </tr>
       <!-- <tr>
         <td width='60%'><h4>Want to know more? Don't be shy!</h4></td>
         <td><a class='button' href='#' >Click here &rarr;</a></td>
       </tr> -->
    </table>
    </td>
  </tr>

        <tr>
          <td class='footer' 
              width='100%' 
              border='0' 
              cellpadding='0' 
              cellspacing='0'  
              style='background-color: #eee;'>
            
            <table border='0' 
                   style='width: 600px; 
                          margin: 0 auto; 
                          font-family: Arial, Helvetica, sans-serif;
                          margin-bottom: 20px;
                          font-size: small; 
                          color: #999;'
                   cellspacing='0'
                   width='600'>
                    <tr>
                      <td width='100%'>
                       $footer
                      </td>
                      
                    </tr>
            </table>
            
        </td>
      </tr>
</table>
</center>";
}
///////////////////////////////////Send mail////////////////////////////////////////////////
// $message = "<div style='width:600px; float:left; background: url(http://srijancreation.com/assets/images/banner.jpg); padding: 20px;'>
//    <div style='text-align:center;'><img src='http://srijancreation.com/assets/images/logo.png'></div>";
//           $message .="<div style='float:left; margin: 25px 0 15px 0; font-size: 35px; text-align: center; width: 600px; color: #fff; text-transform: uppercase;'>Contact by</div>
//    <div style='float:left; width:150px; font-size: 25px; font-weight: bold; color:#fff;'>Name:-</div><div style='float:left; font-size: 25px; width:450px; color:#fff;'>$name</div>
   
//      <div style='float:left; width:150px; font-size: 25px; font-weight: bold; color:#fff;'>Email:-</div><div style='float:left; font-size: 25px; width:450px; color:#fff;'>$email</div>
//        <div style='float:left; width:150px; font-size: 25px; font-weight: bold; color:#fff;'>Phone no:-</div><div style='float:left; font-size: 25px; width:450px; color:#fff;'>$phone</div>
//         <div style='float:left; width:150px; font-size: 25px; font-weight: bold; color:#fff;'>Message:-</div><div style='float:left; font-size: 25px; width:450px; color:#fff;'>$msg</div>
//      ";
//         $message .="</div>";
        $headers = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type:text/html;charset=UTF-8' . "\r\n";

// Additional headers




// echo $message;

$mail=mail($value,$title,$message);
if($mail)
{
	echo 'yes';
}


///////////////////////////////////Send mail////////////////////////////////////////////////
} else {
 
}

                   
               
		header('location:index.php');
	}
}

 ?>