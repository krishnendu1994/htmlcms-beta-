<?php

include('../config.php');
if(isset($_POST))
{
	$form_id=$_POST['form_id'];
	$submit_p=$_POST;
	foreach ($submit_p as $key => $value) {
		$key=$key+1;
		if($value!=null)
		{
			// if($value!=$form_id)
			// {
				$sql="insert into htmlcf(form_id,field_id,value)values('$form_id','$key','$value')";
		$submit_query=$mysqli->query($sql);
		//}
			
		}
		
	}
	// if($submit_query)
	// {
		header('location:../index.php?submit=true');
	//}
}

 ?>