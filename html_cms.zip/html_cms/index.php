<?php include('config.php'); 
if(!isset($mysqli))
{
	 header('location:install.php');
}
if (@$mysqli->connect_error) {
    header('location:install.php');
} 
else
{
	
	include('main/page.php');
	?>
	<link href="assets/css/notifier.style.css" rel="stylesheet" type="text/css" />
 <script src="assets/css/notifier.script.js" />
	<script type="text/javascript">
  $('form').each(function() {
    var id=this.id;
  
    $(this).append("<input type='hidden' name='form_id' value='"+id+"'>");
    //alert(id);
    $(this).attr('action','htmlcf/htmlcf.php');
    $(this).attr('method','post');
    // $(this).submit();
    $(this).find('input, select, textarea').each(function(key){
           // alert(key + ': ' + jQuery(this).val());
            var attr = $(this).attr('name');
  
// For some browsers, `attr` is undefined; for others,
// `attr` is false.  Check for both.
if ( attr == undefined) {

   $(this).attr('name','fm'+key)
}
        });
    
  })
</script>
	<?php
	if(isset($_GET['submit']))
	{
		
		?>
<script type="text/javascript">
addNotifier();
	//alert('Thank You For Contacting Us');
</script>
		
	<?php
	}
}
?>