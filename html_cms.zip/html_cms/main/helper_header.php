<?php include('./config.php'); 
?>
<script type="text/javascript">
   window.jQuery || document.write('<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"><\/script>');
 </script>
 <link href="manage/assets/minimalist-basic/content.css" rel="stylesheet" type="text/css" />
 <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="../assets/css/notifier.style.min.css" rel="stylesheet" type="text/css" />
 <script src="assets/css/notifier.script.js" ></script>
<?php
 $sql_chk="select * from theme where status='active'";
   $query_chk=$mysqli->query($sql_chk);
   $row_chk=$query_chk->fetch_array();
   $theme_id=$row_chk['id'];

   		$sql_theme_script_chk="select * from theme_style where theme_id='$theme_id'";
   $query_theme_script_chk=$mysqli->query($sql_theme_script_chk);
   while($row_theme_script_chk=$query_theme_script_chk->fetch_array())
   {
   	 $ttu=$row_theme_script_chk['style'];
       $ttu=base64_decode($ttu);
   	 ?>
   	  <link rel="stylesheet" type="text/css" href="<?php echo $ttu; ?>">
   	 <?php
   }

   

   $sql_theme_chk="select * from theme_header where theme_id='$theme_id'";
   $query_theme_chk=$mysqli->query($sql_theme_chk);
   $row_theme_chk=$query_theme_chk->fetch_array();
  $header=base64_decode($row_theme_chk['header']);

$html = $header;
$doc = new DOMDocument();
libxml_use_internal_errors(true);
$doc->loadHTML($html);
$finder = new DomXPath($doc);

  foreach ($doc->getElementsByTagName('a') as $img) {
    // put your replacement code here
  $href2=$img->getAttribute('href');
 $withoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $href2);
  $sql_chk_th="select * from theme_page where theme_id='$theme_id' and page_name='$withoutExt'";
    $query_chk_th=$mysqli->query($sql_chk_th);
    $row_chk_th=$query_chk_th->fetch_array();



  $rtt='page.php?page_id='.$row_chk_th['id'];
  if($row_chk_th['id']==null)
{
  $rtt='#';
}
  //$new_src_url=str_replace($rtt,"",$href2);
  $img->setAttribute( 'href', $rtt );
}

$body = $doc->getElementsByTagName('header');
if ( $body && 0<$body->length ) {
    $body = $body->item(0);
    $header=$doc->savehtml($body);
}

 ?>
 
 <script type="text/javascript">
   (function () {
  var span = document.createElement('span'),
      message = document.getElementById('message');

  span.className = 'fa';
  span.style.display = 'none';
  document.body.insertBefore(span, document.body.firstChild);

  function css(element, property) {
    return window.getComputedStyle(element, null).getPropertyValue(property);
  }

  if (css(span, 'font-family') === 'FontAwesome') {
    message.innerHTML += 'Yay, Font Awesome loaded!';
  } else {
    message.innerHTML += 'Oops, Font Awesome didn\'t load!';
  }
  document.body.removeChild(span);
})();
 </script>
<?php  $sql_chk_html="select * from htmlcf_setting where id=1";
   $query_chk_html=$mysqli->query($sql_chk_html);
   $row_chk_html=$query_chk_html->fetch_array(); ?>
 <script>
            function addNotifier(){
                var notifier = $.Notifier('<?php echo $row_chk_html['contact_header']; ?>', '<?php echo $row_chk_html['contact_content']; ?>', "success", {
                    vertical_align:"center",
                    rtl:false,
                    btns:[
                        {
                            label:"ok",
                            type:"success",
                            // onClick:function(){
                            //     alert('Clicked');
                            // }
                        },
                        {
                            label:"cancel",
                            type:"default",
                            // onClick:function(){
                            //     debugger;
                            // }
                        }                        
                    ],
                    callback:function(){
                        debugger;
                    }
                });

            }
        </script>