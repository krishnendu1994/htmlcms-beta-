<?php include('./config.php'); 

 $sql_chk="select * from theme where status='active'";
   $query_chk=$mysqli->query($sql_chk);
   $row_chk=$query_chk->fetch_array();
  $theme_id=$row_chk['id'];

   $sql_theme_chk="select * from theme_footer where theme_id='$theme_id'";
   $query_theme_chk=$mysqli->query($sql_theme_chk);
   $row_theme_chk=$query_theme_chk->fetch_array();
  $footer=base64_decode($row_theme_chk['footer']);


  $html = $footer;
$doc = new DOMDocument();
libxml_use_internal_errors(true);
$doc->loadHTML($html);
$finder = new DomXPath($doc);

  foreach ($doc->getElementsByTagName('a') as $img) {
    // put your replacement code here
  $href2=$img->getAttribute('href');
 $withoutExt = preg_replace('/\\.[^.\\s]{3,4}$/', '', $href2);
  $sql_chk_th="select * from theme_page where theme_id='$theme_id' and page_name='$withoutExt'";
    $query_chk_th=$mysqli->query($sql_chk_th);
    $row_chk_th=$query_chk_th->fetch_array();



  $rtt='page.php?page_id='.$row_chk_th['id'];
  if($row_chk_th['id']==null)
{
  $rtt='#';
}
  //$new_src_url=str_replace($rtt,"",$href2);
  $img->setAttribute( 'href', $rtt );
}

$body = $doc->getElementsByTagName('footer');
if ( $body && 0<$body->length ) {
    $body = $body->item(0);
    $footer=$doc->savehtml($body);
}






   $sql_theme_style_chk="select * from theme_script where theme_id='$theme_id'";
   $query_theme_style_chk=$mysqli->query($sql_theme_style_chk);
   while($row_theme_style_chk=$query_theme_style_chk->fetch_array())
   {
   	  $ttu1=$row_theme_style_chk['script'];
      $ttu1=base64_decode($ttu1);
   	 ?>
   	  <script src="<?php echo $ttu1; ?>"></script>
   	 <?php
   }

 ?>