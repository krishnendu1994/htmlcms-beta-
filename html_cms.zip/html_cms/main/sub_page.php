<?php include('./config.php'); 
include('helper_header.php');
include('helper_footer.php');  
 $sql_chk="select * from theme where status='active'";
   $query_chk=$mysqli->query($sql_chk);
   $row_chk=$query_chk->fetch_array();
   $theme_id=$row_chk['id'];

    $sql_chk_th="select * from theme where id='$theme_id'";
   $query_chk_th=$mysqli->query($sql_chk_th);
   $row_chk_th=$query_chk_th->fetch_array();
   $theme_name=$row_chk_th['theme_name'];

$theme_page_id=$_GET['page_id'];


 $path = dirname(__FILE__).'/';
   $sql_theme_index_body_chk="select * from theme_body where theme_id='$theme_id' and id='$theme_page_id'";
   $query_theme_index_body_chk=$mysqli->query($sql_theme_index_body_chk);
   while($row_theme_index_body_chk=$query_theme_index_body_chk->fetch_array())
   {
   echo	 $header.$str=$row_theme_index_body_chk['page_content'].$footer;
   	 


   }

  
 
 ?>

  <script type="text/javascript">
     var imgTags = $('img').each(function() {
                var urlRelative = $(this).attr("src");
                var urlAbsolute = 'themes/'+'<?php echo $theme_name; ?>'+'/'  + urlRelative;
                //$(this).attr("src").replace(urlRelative, urlAbsolute); // problem here
                $(this).attr("src", urlAbsolute)
            });
</script>