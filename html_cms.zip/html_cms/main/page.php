<?php include('./config.php'); 
include('helper_header.php');
include('helper_footer.php'); 
?>

<?php 
 $sql_chk="select * from theme where status='active'";
   $query_chk=$mysqli->query($sql_chk);
   $row_chk=$query_chk->fetch_array();
   $theme_id=$row_chk['id'];

    $sql_chk_th="select * from theme where id='$theme_id'";
   $query_chk_th=$mysqli->query($sql_chk_th);
   $row_chk_th=$query_chk_th->fetch_array();
   $theme_name=$row_chk_th['theme_name'];

 $path = dirname(__FILE__).'/';
   $sql_theme_index_body_chk="select * from theme_body where theme_id='$theme_id' and page_name='index'";
   $query_theme_index_body_chk=$mysqli->query($sql_theme_index_body_chk);
   while($row_theme_index_body_chk=$query_theme_index_body_chk->fetch_array())
   {
   echo	 $header.$str=base64_decode($row_theme_index_body_chk['page_content']).$footer;
   	 


   }

  
 
 ?>

  <script type="text/javascript">

     var imgTags = $('img').each(function() {
                var urlRelative = $(this).attr("src");
                var urlAbsolute = 'themes/'+'<?php echo $theme_name; ?>'+'/'  + urlRelative;
                  if (urlRelative.indexOf('../themes/'+'<?php echo $theme_name; ?>'+'/') >= 0)
                {
                 urlRelative=urlRelative.replace("../", "");
                  var urlAbsolute =urlRelative
                }
                //$(this).attr("src").replace(urlRelative, urlAbsolute); // problem here
                $(this).attr("src", urlAbsolute)
            });



       var imgTags1 = $('div').each(function() {
        if ($(this).css('background-image') != 'none') {
   var urlRelative1 = $(this).css('background-image');
                var urlAbsolute2 = 'themes/'+'<?php echo $theme_name; ?>';
                //$(this).attr("src").replace(urlRelative, urlAbsolute); // problem here
                urlRelative1 = urlRelative1.replace('url(','').replace(')','').replace(/\"/gi, "");
      
   var l = window.location;
var base_url = l.protocol + "//" + l.host + "/" + l.pathname.split('/')[1];    

// var yuyyyyy=urlRelative1.replace(base_url, base_url+'/'+urlAbsolute2);
var yuyyyyy=urlRelative1;
// alert(urlRelative1);
// alert(yuyyyyy);
 yuyyyyy='url('+yuyyyyy+')'
               // var yuyu="background-image:url("+urlAbsolute1+")";
                $(this).css("background-image", yuyyyyy)
}
               
            });
</script>