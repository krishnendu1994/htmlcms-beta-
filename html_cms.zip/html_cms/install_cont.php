<?php
 $db_host=$_POST['db_host'];
		  	 $db_email=$_POST['db_email'];
		  	 $db_user=$_POST['db_user'];
		  	 $db_pass=$_POST['db_pass'];

		  	 $conn1 = new mysqli($db_host, $db_user, $db_pass);
// Check connection
if ($conn1->connect_error) {
   // die("Connection failed: " . $conn1->connect_error);
} 

// Create database
// $sql = "CREATE DATABASE ".$db_email;
// if ($conn1->query($sql) === TRUE) {
//     echo "Database created successfully";
    @$conn = new mysqli($db_host, $db_user, $db_pass, $db_email);
// Check connection
if ($conn->connect_error) {
   echo "Database Not Found";
} 

// sql to create table
$sqls = "CREATE TABLE theme (
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
theme_name VARCHAR(250) NOT NULL,
status VARCHAR(250) NOT NULL
)";

$sql2 = "CREATE TABLE admin (
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
user_name VARCHAR(250) NOT NULL,
password VARCHAR(250) NOT NULL
)";

$sql3 = "CREATE TABLE htmlcf (
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
form_id VARCHAR(250) NOT NULL,
field_id TEXT NOT NULL,
dm TEXT NOT NULL,
value TEXT NOT NULL
)";

$sql4 = "CREATE TABLE htmlcf_setting (
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
reply_mail VARCHAR(250) NOT NULL,
logo TEXT NOT NULL,
title TEXT NOT NULL,
content TEXT NOT NULL,
footer TEXT NOT NULL,
template TEXT NOT NULL,
contact_header TEXT NOT NULL,
contact_content TEXT NOT NULL
)";

if (@$conn->query($sqls) === TRUE) {
	$conn->query($sql2);
    $conn->query($sql3);
      $conn->query($sql4);

   
} else {
    
}
if (!$conn->connect_error) {
    $mysqli="";
    $write_conn="<?php \$mysqli = new mysqli('$db_host','$db_user','$db_pass','$db_email'); ?>";
$myfile=fopen('config.php', 'w');
fwrite($myfile, $write_conn);
fclose($myfile);


$mail_body="<p style='color:#A9A9A9; text-align:left;' >
       Dear  [Name]
            </p>

    <p style='color:#000;'>
        We appreciate you contacting. One of our colleagues will get back to you shortly. 
    </p> <p style='font-size:0.8em; color:#A9A9A9; text-decoration:none;'>
       Have a great day!
    </p>";
    $mail_body=htmlspecialchars($mail_body);
    $ggggju=htmlspecialchars('<h2>Thank you for getting in touch!</h2>');
      $sql_index="insert into `htmlcf_setting`( title,content,template,contact_header,contact_content) values('$ggggju','$mail_body','mail.html','Thank You','Thank You For Submitting Your Message.')";
    @$query_index=$conn->query($sql_index);


}


// } else {
//     echo "Error creating database: " . $conn1->error;
// }







?>