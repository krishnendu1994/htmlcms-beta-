<?php
 $db_host=$_POST['db_host'];
		  	 $db_email=$_POST['db_email'];
		  	 $db_user=$_POST['db_user'];
		  	 $db_pass=$_POST['db_pass'];

		  	 $conn = new mysqli($db_host, $db_user, $db_pass);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

// Create database
$sql = "CREATE DATABASE ".$db_email;
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
    $mysqli="";
    $write_conn="<?php new mysqli('$db_host','$db_user','$db_pass','$db_email'); ?>";
$myfile=fopen('config.php', 'w');
fwrite($myfile, $write_conn);
fclose($myfile);
} else {
    echo "Error creating database: " . $conn->error;
}
?>