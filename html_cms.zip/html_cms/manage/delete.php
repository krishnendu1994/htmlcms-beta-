<?php 

include('../config.php');

echo $theme_id=$_GET['theme_id'];
echo "delete * from theme where id='$theme_id'";

$mysqli->query("delete  from theme where id='$theme_id'");
$mysqli->query("delete  from theme_header where theme_id='$theme_id'");
$mysqli->query("delete  from theme_footer where theme_id='$theme_id'");
$mysqli->query("delete  from theme_page where theme_id='$theme_id'");
$mysqli->query("delete  from theme_body where theme_id='$theme_id'");
$mysqli->query("delete  from theme_script where theme_id='$theme_id'");
$mysqli->query("delete  from theme_style where theme_id='$theme_id'");

 header('location:themes.php');
