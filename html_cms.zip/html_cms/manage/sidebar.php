  <li>
                        <a href="themes.php" class=" hvr-bounce-to-right"><i class="fa fa-picture-o nav_icon "></i><span class="nav-label">Themes</span> </a>
                    </li>
                   
                    <li>
                        <a href="pages.php" class=" hvr-bounce-to-right"><i class="fa fa-file-text-o nav_icon"></i> <span class="nav-label">Pages</span></a>
                        
                    </li>
                     <li>
                        <a href="css_custom.php" class=" hvr-bounce-to-right"><i class="fa fa-file-text-o nav_icon"></i> <span class="nav-label">Css Editor</span></a>
                        
                    </li>
                      <li>
                        <a href="menu.php" class=" hvr-bounce-to-right"><i class="fa fa-file-text-o nav_icon"></i> <span class="nav-label">Menu</span></a>
                        
                    </li>
					 <li>
                        <a href="contactform.php" class=" hvr-bounce-to-right"><i class="fa fa-phone nav_icon"></i> <span class="nav-label">Contact Forms</span> </a>
                    </li>
                    
                    <li>
                        <a href="contact_setting.php" class=" hvr-bounce-to-right"><i class="fa fa-cog nav_icon"></i> <span class="nav-label">Contact Setting</span> </a>
                    </li>
                    