<?php
header("X-XSS-Protection: 0");
include('../config.php');
 $_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
if (@$_POST['hidContent']) {
include('../config.php');
   $theme_id=$_POST['theme_id'];
   $page_id=$_POST['page_id'];

    $myFile = "content-body.html";
    $stringData = $_POST['hidContent'];
    file_put_contents($myFile,$stringData);

$html = file_get_contents($myFile);
$doc = new DOMDocument();
libxml_use_internal_errors(true);
$doc->loadHTML($html);
$finder = new DomXPath($doc);

$node = $finder->query("//header");
 $theme_header=$doc->saveHTML($node->item(0));

$theme_header=base64_encode($theme_header);
$sql_page_header="update `theme_header`  set header='$theme_header' where theme_id='$theme_id')";
    $query_page_header=$mysqli->query($sql_page_header);
$node_1 = $finder->query("//footer");
  $theme_footer=$doc->saveHTML($node_1->item(0));
$theme_footer=base64_encode($theme_footer);

$sql_page_footer="update `theme_footer`  set footer='$theme_footer' where theme_id='$theme_id')";
    $query_page_footer=$mysqli->query($sql_page_footer);

for($c = 1; $a = $doc->getElementsByTagName('header')->item(0); $c++) {
    $a->parentNode->replaceChild(
        $doc->createTextNode(print_r(' ', $c)),
        $a
    );
}
for($cd = 1; $ad = $doc->getElementsByTagName('footer')->item(0); $cd++) {
    $ad->parentNode->replaceChild(
        $doc->createTextNode(print_r(' ', $cd)),
        $ad
    );
}
// for($cde = 1; $ade = $doc->getElementsByTagName('script')->item(0); $cde++) {
//     $ade->parentNode->removeChild(
//        $doc->getElementsByTagName('script')->item(0)
//     );
// }

// $doc->getElementsByTagName('body');
//  $theme_body_index=$doc->saveHTML();

$body = $doc->getElementsByTagName('body');
if ( $body && 0<$body->length ) {
    $body = $body->item(0);
    $theme_body_index=$doc->savehtml($body);
}


 $theme_body_index=base64_encode($theme_body_index);
  $sql_page_body="update `theme_body` set page_content='".$theme_body_index."' where id='$page_id'";
    $query_page_body=$mysqli->query($sql_page_body);





 // header("Location: pages.php");
  //exit;
}
?>
<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8">
    <title>Example</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">  

    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,600,800' rel='stylesheet' type='text/css'>
    <link href="assets/minimalist-basic/content.css" rel="stylesheet" type="text/css" />
  
 <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css " rel="stylesheet" type="text/css" />
    <link href="scripts/contentbuilder.css" rel="stylesheet" type="text/css" />
    <link href="style_respon.css" rel="stylesheet" type="text/css" />
    <style>
    .header {position:relative;margin:0 0 50px;padding:0;box-sizing:border-box;background-size: cover;color:#fff !important}
    .headeroverlay {background-color: #000;opacity: 0.2;position:absolute;width:100%;height:100%;}
    #headerarea {padding:130px 0 110px;position: relative;}

        body {margin:0 0 57px} /* give space 70px on the bottom for panel */
        #panelCms {width:100%;height:57px;border-top: #eee 1px solid;background:rgba(255,255,255,0.95);position:fixed;bottom:0;padding:10px;box-sizing:border-box;text-align:center;white-space:nowrap;z-index:10001;}
        #panelCms button {border-radius:4px;padding: 10px 15px;text-transform:uppercase;font-size: 11px;letter-spacing: 1px;line-height: 1;}
    </style>
</head>
<body>

<!-- HEADER AREA -->
<?php 

$sql_chk="select * from theme where status='active'";
   $query_chk=$mysqli->query($sql_chk);
   $row_chk=$query_chk->fetch_array();
   $theme_id=$row_chk['id'];

        $sql_theme_script_chk="select * from theme_style where theme_id='$theme_id'";
   $query_theme_script_chk=$mysqli->query($sql_theme_script_chk);
   while($row_theme_script_chk=$query_theme_script_chk->fetch_array())
   {
     $ttu=$row_theme_script_chk['style'];
       $ttu=base64_decode($ttu);
     ?>
      <link rel="stylesheet" type="text/css" href="../<?php echo $ttu; ?>">
     <?php
   }

   

   $sql_theme_chk="select * from theme_header where theme_id='$theme_id'";
   $query_theme_chk=$mysqli->query($sql_theme_chk);
   $row_theme_chk=$query_theme_chk->fetch_array();
  $header=base64_decode($row_theme_chk['header']);
  // $header=$row_theme_chk['header'];
$sql_chk="select * from theme where status='active'";
   $query_chk=$mysqli->query($sql_chk);
   $row_chk=$query_chk->fetch_array();
  $theme_id=$row_chk['id'];

   $sql_theme_chk="select * from theme_footer where theme_id='$theme_id'";
   $query_theme_chk=$mysqli->query($sql_theme_chk);
   $row_theme_chk=$query_theme_chk->fetch_array();
  $footer=base64_decode($row_theme_chk['footer']);
   $sql_theme_style_chk="select * from theme_script where theme_id='$theme_id'";
   $query_theme_style_chk=$mysqli->query($sql_theme_style_chk);
   while($row_theme_style_chk=$query_theme_style_chk->fetch_array())
   {
      $ttu1=$row_theme_style_chk['script'];
      $ttu1=base64_decode($ttu1);
     ?>
      <script src="../<?php echo $ttu1; ?>"></script>
     <?php
   } 
?>
<script type="text/javascript">
   window.jQuery || document.write('<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"><\/script>');
 </script>
 <script type="text/javascript" src='index_res.js'></script>
<!-- CONTENT AREA -->
<?php $page_id=$_GET['page_id']; ?>
<div id="device" class="desktop">
 <iframe  id="webframe" src="../page.php?page_id=<?php echo $page_id; ?>" ></iframe>
<div id="contentarea" class="container">

    <?php
 $sql_chk="select * from theme where status='active'";
   $query_chk=$mysqli->query($sql_chk);
   $row_chk=$query_chk->fetch_array();
   $theme_id=$row_chk['id'];

    $sql_chk_th="select * from theme where id='$theme_id'";
   $query_chk_th=$mysqli->query($sql_chk_th);
   $row_chk_th=$query_chk_th->fetch_array();
   $theme_name=$row_chk_th['theme_name'];


$sql_chk_th_page="select * from theme_page where id='$page_id'";
   $query_chk_th_page=$mysqli->query($sql_chk_th_page);
    $row_chk_th_page=$query_chk_th_page->fetch_array();
    $page_namee=$row_chk_th_page['page_name'];

 $path = dirname(__FILE__).'/';
   $sql_theme_index_body_chk="select * from theme_body where theme_id='$theme_id' and page_name='$page_namee'";
   $query_theme_index_body_chk=$mysqli->query($sql_theme_index_body_chk);
  $row_theme_index_body_chk=$query_theme_index_body_chk->fetch_array();
  
   echo  $header.$str=base64_decode($row_theme_index_body_chk['page_content']).$footer;
     


 
$page_content_id=$row_theme_index_body_chk['id'];
  
 
 ?>

 
</div>

<br /><br />
</div>
<!-- Hidden Form Fields to post content -->
<form id="frmContent" method="post" action="page_submit.php">
  <input id="hidHeader" name="hidHeader" type="hidden" />
  <input id="page_id" name="page_id" value="<?php echo $page_content_id; ?>" type="hidden" />
  <input id="theme_id" name="theme_id" value="<?php echo $theme_id; ?>" type="hidden" />
  <input id="hidContent" name="hidContent" type="hidden" />
</form>
 <script type="text/javascript">

     var imgTags = $('img').each(function() {
                var urlRelative = $(this).attr("src");

                var urlAbsolute = '../themes/'+'<?php echo $theme_name; ?>'+'/'  + urlRelative;
                  if (urlRelative.indexOf('../themes/'+'<?php echo $theme_name; ?>'+'/') >= 0)
                {
                  var urlAbsolute =urlRelative
                }
                //$(this).attr("src").replace(urlRelative, urlAbsolute); // problem here
                $(this).attr("src", urlAbsolute)
            });



       var imgTags1 = $('div').each(function() {
        if ($(this).css('background-image') != 'none') {
   var urlRelative1 = $(this).css('background-image');
                var urlAbsolute2 = 'themes/'+'<?php echo $theme_name; ?>';
                //$(this).attr("src").replace(urlRelative, urlAbsolute); // problem here
                urlRelative1 = urlRelative1.replace('url(','').replace(')','').replace(/\"/gi, "");
      
   var l = window.location;
var base_url = l.protocol + "//" + l.host + "/" + l.pathname.split('/')[1];    

 var yuyyyyy=urlRelative1.replace(base_url+'/manage', base_url+'/'+urlAbsolute2);
// alert(urlRelative1);
 //alert(urlRelative1);
 yuyyyyy='url('+yuyyyyy+')'
               // var yuyu="background-image:url("+urlAbsolute1+")";
                $(this).css("background-image", yuyyyyy)
}
               
            });
</script>
<!-- CUSTOM PANEL (can be used for "save" button or your own custom buttons) -->
<div id="panelCms">
<!--  <ul id="device-screen">
 
            <li id="phone"></li>
            <li id="phone-l"></li>
            <li id="tablet"></li>
            <li id="tablet-l"></li>
            <li id="desktop" ></li>
        </ul> -->
<!-- <p class="btn " style="color:#000 !important"> Responsive : <input type="checkbox" class="res" name="responsive" value="1"></p>&nbsp;
   -->  
    <button onclick="view()" class="btn btn-default"> View HTML </button> &nbsp;
    <button onclick="save()" class="btn btn-primary"> Save </button> &nbsp;
</div>
<script type="text/javascript">
  setInterval(function(){  if($('.res:checked').length==1){  $('#webframe').show(); $('#contentarea').hide(); }else{ $('#webframe').hide(); $('#contentarea').show();  }  }, 100);
</script>
<!-- <script src="scripts/jquery-1.11.1.min.js" type="text/javascript"></script> -->
<script src="scripts/jquery-ui.min.js" type="text/javascript"></script>
<script src="scripts/contentbuilder.js" type="text/javascript"></script>
<script src="scripts/saveimages.js" type="text/javascript"></script>
<script type="text/javascript">
window.onload = function()
{
    if (window.jQuery)
    {
       
    }
    else
    {
       var head = document.getElementsByTagName("head")[0];
    var js = document.createElement("script");
    js.type = "text/javascript";
    js.src = 'scripts/jquery-1.11.1.min.js';
    head.appendChild(js);
        alert('jQuery is not loaded');
    }
}
</script>
<script type="text/javascript">
    jQuery(document).ready(function ($) {

        //Run the builder
        $("#contentarea,#headerarea").contentbuilder({
            zoom: 0.85,
            snippetOpen: true,
            imageselect: 'images.php',
            fileselect: 'link.php',
            iconselect: 'assets/ionicons/selecticon.html',

            snippetFile: 'assets/minimalist-basic/snippets.html',
            toolbar: 'left',
            axis: 'y'
        });

    });

    function save() {

        //Save Images
        $("body").saveimages({
            handler: 'saveimage.php',
            onComplete: function () {

        //Submit Content
              //  var sHeader = $('#headerarea').data('contentbuilder').html();

        var sContent = $('#contentarea').data('contentbuilder').html();
        //$('#hidHeader').val(sHeader);
        $('#hidContent').val(sContent);     
        $('#frmContent').submit(); 
 
            }
        });
        $("body").data('saveimages').save();

        return false;

    }

    function view() {
        $('#contentarea').data('contentbuilder').viewHtml(); //this is just a helper method to view/edit HTML source.
    return false;
    }
</script>

</body>
</html>
