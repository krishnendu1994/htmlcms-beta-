<?php

include('../config.php');
 $data=$_POST['data'];
$urls=$_POST['urls'];
 $myFile = fopen($urls,"w"); 

 if(fputs($myFile, $data))
 {
 	?>
 	<script type="text/javascript">
 		window.location='css_custom.php';
 	</script>
 	<?php 
 } 

 ?>