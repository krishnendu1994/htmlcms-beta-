<?php 

include('../config.php');
  //print_r($_POST);
echo  $email_from=$_POST['email_from'];
  $email_title=$_POST['email_title'];
  $email_content=htmlspecialchars($_POST['email_content']);
  $email_header_logo=$_POST['email_header_logo'];
  $email_footer=$_POST['email_footer'];
  $email_template=$_POST['email_template'];
 
  $contact_message=$_POST['contact_message'];
  $contact_content=$_POST['contact_content'];
echo  $sql="update htmlcf_setting set reply_mail='$email_from',logo='$email_header_logo',title='$email_title',content='$email_content',footer='$email_footer',template='$email_template',contact_header='$contact_message',contact_content='$contact_content'";
    $submit_query=$mysqli->query($sql);
  if($submit_query)
  {
    header('location:contact_setting.php');
  }



?>