<?php 

if (@$_POST['hidContent']) {
include('../config.php');
 echo  $theme_id=$_POST['theme_id'];

$sql_page1="select * from `theme` where id='$theme_id'";
    $query_page1=$mysqli->query($sql_page1);
   $thh=$query_page1->fetch_array();
    $th_name=$thh['theme_name'];

   $page_name=$_POST['page_name'];
if (!file_exists('../themes/'.$th_name.'/'.$page_name.'.html')) {
  fopen('../themes/'.$th_name.'/'.$page_name.'.html', "w");
}
    $myFile = "content-body.html";
    $stringData = $_POST['hidContent'];
    file_put_contents($myFile,$stringData);

$html = $stringData;
$doc = new DOMDocument();
libxml_use_internal_errors(true);
$doc->loadHTML($html);
$finder = new DomXPath($doc);

$node = $finder->query("//header");
 $theme_header=$doc->saveHTML($node->item(0));
 $th_h=$theme_header;
$theme_header=base64_encode($theme_header);
 $sql_page_header="update `theme_header`  set header='$theme_header' where theme_id='$theme_id'";
    $query_page_header=$mysqli->query($sql_page_header);
    if($query_page_header)
    {
      echo 'yes';
    }
$node_1 = $finder->query("//footer");
  $theme_footer=$doc->saveHTML($node_1->item(0));
  $th_f=$theme_footer;
$theme_header=base64_encode($theme_footer);

$sql_page_footer="update `theme_footer`  set footer='".base64_encode($theme_footer)."' where theme_id='$theme_id'";
    $query_page_footer=$mysqli->query($sql_page_footer);


for($c = 1; $a = $doc->getElementsByTagName('header')->item(0); $c++) {
    $a->parentNode->replaceChild(
        $doc->createTextNode(print_r(' ', $c)),
        $a
    );
}
for($cd = 1; $ad = $doc->getElementsByTagName('footer')->item(0); $cd++) {
    $ad->parentNode->replaceChild(
        $doc->createTextNode(print_r(' ', $cd)),
        $ad
    );
}
// for($cde = 1; $ade = $doc->getElementsByTagName('script')->item(0); $cde++) {
//     $ade->parentNode->removeChild(
//        $doc->getElementsByTagName('script')->item(0)
//     );
// }

// $doc->getElementsByTagName('body');
//  $theme_body_index=$doc->saveHTML();

$body = $doc->getElementsByTagName('body');
if ( $body && 0<$body->length ) {
    $body = $body->item(0);
    $theme_body_index=$doc->savehtml($body);
}

$sql_page="insert into `theme_page`( theme_id,page_name) values('$theme_id','$page_name')";
    $query_page=$mysqli->query($sql_page);
     $th_b=$theme_body_index;
 $theme_body_index=base64_encode($theme_body_index);

  $sql_page_body="insert into `theme_body`( theme_id,page_name,page_content) values('$theme_id','$page_name','".$theme_body_index."')";
    $query_page_body=$mysqli->query($sql_page_body);


$handle = fopen('../themes/'.$th_name.'/'.$page_name.'.html','w+'); fwrite($handle,$th_h.$th_f.$th_b); fclose($handle);

  header("Location: pages.php");
  exit;
}

?>