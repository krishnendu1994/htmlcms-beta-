/* BEST VIEW in FULL MODE (CTRL + 8) */
$(function() {
   $("#device-screen").on("click", "li" ,function() {
       DeviceID = $(this).attr("id");
     $("#device").removeClass().addClass(DeviceID);
});

	function UpdateFrame() {
      url = $("#getURL").val();
    if (url.match(/^http:/)) {
            $('#webframe').attr('src', url);
        }
      else  {
          validURL = 'http://' + url;
          $('#webframe').attr('src', validURL);
        }
      }

    $("#button").click(function() {
      UpdateFrame();
	});

	$('#getURL').keypress(function(e){
      if(e.which == 13){
       UpdateFrame();
       }
      });
});