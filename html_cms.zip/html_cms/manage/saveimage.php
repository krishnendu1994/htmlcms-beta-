﻿<?php
header('Cache-Control: no-cache, must-revalidate');
include('../config.php');
$sql_chk_th="select * from theme where status='Active'";
   $query_chk_th=$mysqli->query($sql_chk_th);
   $row_chk_th=$query_chk_th->fetch_array();
   $theme_name=$row_chk_th['theme_name'];
   if (!file_exists('../themes/'.$theme_name.'/upload')) {
    mkdir('../themes/'.$theme_name.'/upload', 0777, true);
}
$path1='../themes/'.$theme_name.'/upload/';
//Specify url path
//$path = 'assets/'; 

//Read image
$count = $_REQUEST['count'];
if($count!=null)
{
$b64str = $_REQUEST['hidimg-' . $count]; 
$imgname = $_REQUEST['hidname-' . $count]; 
$imgtype = $_REQUEST['hidtype-' . $count]; 

//Generate random file name here
if($imgtype == 'png'){
	$image = $imgname . '-' . base_convert(rand(),10,36) . '.png'; 
} else {
	$image = $imgname . '-' . base_convert(rand(),10,36) . '.jpg'; 
}

//Save image

//$success1 = file_put_contents($path . $image, base64_decode($b64str)); 
$success = file_put_contents($path1 . $image, base64_decode($b64str)); 
if ($success === FALSE) {

  if (!file_exists($path1)) {
    echo "<html><body onload=\"alert('Saving image to folder failed. Folder ".$path1." not exists.')\"></body></html>";
  } else {
    echo "<html><body onload=\"alert('Saving image to folder failed. Please check write permission on " .$path1. "')\"></body></html>";
  }
    
} else {
  //Replace image src with the new saved file
  echo "<html><body onload=\"parent.document.getElementById('img-" . $count . "').setAttribute('src','" . 'upload/' . $image . "');  parent.document.getElementById('img-" . $count . "').removeAttribute('id') \"></body></html>";
}
}

?>
