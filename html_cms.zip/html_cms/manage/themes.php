
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<?php include('../helper/url_helper.php'); include('../config.php');  ?>
<!DOCTYPE HTML>
<html>
<head>
<title>Stenum Asia</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Minimal Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link href="<?php echo $base_url; ?>assets/css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!--<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />-->
<!-- Custom Theme files -->
<link href="<?php echo $base_url; ?>assets/css/style.css" rel='stylesheet' type='text/css' />
<link href="<?php echo $base_url; ?>assets/css/font-awesome.css" rel="stylesheet"> 
<script src="<?php echo $base_url; ?>assets/js/jquery.min.js"> </script>
<script src="<?php echo $base_url; ?>assets/js/bootstrap.min.js"> </script>
  
<!-- Mainly scripts -->
<script src="<?php echo $base_url; ?>assets/js/jquery.metisMenu.js"></script>
<script src="<?php echo $base_url; ?>assets/js/jquery.slimscroll.min.js"></script>
<!-- Custom and plugin javascript -->
<link href="<?php echo $base_url; ?>assets/css/custom.css" rel="stylesheet">
<script src="<?php echo $base_url; ?>assets/js/custom.js"></script>
<script src="<?php echo $base_url; ?>assets/js/screenfull.js"></script>
		<script>
		$(function () {
			$('#supported').text('Supported/allowed: ' + !!screenfull.enabled);

			if (!screenfull.enabled) {
				return false;
			}

			

			$('#toggle').click(function () {
				screenfull.toggle($('#container')[0]);
			});
			

			
		});
		</script>



</head>
<body>
<div id="wrapper">
        <!----->
        <nav class="navbar-default navbar-static-top" role="navigation">
             <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
               <h1> <a class="navbar-brand" target='_blank' href="../">View Site</a></h1>         
			   </div>
			 <div class=" border-bottom">
        	<div class="full-left">
        	  <section class="full-top">
				<button id="toggle"><i class="fa fa-arrows-alt"></i></button>	
			</section>
			
            <div class="clearfix"> </div>
           </div>
     
       
            <!-- Brand and toggle get grouped for better mobile display -->
		 
		   <!-- Collect the nav links, forms, and other content for toggling -->
		    <div class="drop-men" >
		        <ul class=" nav_1">
		           
		    		
					<li class="dropdown">
		              <a href="#" class="dropdown-toggle dropdown-at" data-toggle="dropdown"><span class=" name-caret">Cms<i class="caret"></i></span><img src="<?php echo $base_url; ?>assets/images/wo.jpg"></a>
		              
		            </li>
		           
		        </ul>
		     </div><!-- /.navbar-collapse -->
			<div class="clearfix">
       
     </div>
	  
		    <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
				
                  <?php include 'sidebar.php'; ?>
                </ul>
            </div>
			</div>
        </nav>
		 <div id="page-wrapper" class="gray-bg dashbard-1">
       <div class="content-main">
 
 	<!--banner-->	
		    <div class="banner row">
		    <div class="col-sm-6"><h2>
			<a href="index.html">Home</a>
			<i class="fa fa-angle-right"></i>
				<span>Themes</span>
				</h2></div>
		    	
				<div class="col-sm-6"><a href="../theme_upload.php" class="btn btn-sm btn-success warning_1">Add A New Theme</a></div>
		    </div>
		<!--//banner-->
 	 <!--gallery-->
 	 <br>
 	 <div class="gallery">
<?php
$sql_chk="select * from theme";
   $query_chk=$mysqli->query($sql_chk);
   while($row_chk=$query_chk->fetch_array())
   {
   $theme_id=$row_chk['id'];

    $sql_chk_th="select * from theme where id='$theme_id'";
   $query_chk_th=$mysqli->query($sql_chk_th);
   $row_chk_th=$query_chk_th->fetch_array();
   $theme_name=$row_chk_th['theme_name'];
   ?>
   <input type="hidden" id="theme_idd<?php echo $theme_id; ?>" value="<?php echo $theme_id; ?>">
 	 	<div class="col-md">
 	 		<div class="gallery-img">
 	 		<a href="<?php echo $base_url; ?>/themes/<?php echo $theme_name; ?>/preview.png" class="b-link-stripe b-animate-go  swipebox"  title="Image Title" >
				 <img class="img-responsive " src="<?php echo $base_url; ?>/themes/<?php echo $theme_name; ?>/preview.png" alt="" />   
					<span class="zoom-icon"> </span> </a>
			</a>
			</div>	
 	 		<div class="text-gallery">
 	 			<h6><?php echo $theme_name; ?></h6><br>
 	 			<?php if($row_chk['status']=='Active'){ ?><h6>
 	 			<?php
 	 				
 	 				 ?><button type="button" class="btn btn-sm btn-success warning_1">Activated</button><?php }else{ ?><button type="button" class="btn btn-sm btn-default active_<?php echo $theme_id; ?>">Activate</button><?php  } ?></h6>
 	 				 <h6><a href="delete.php?theme_id=<?php echo $theme_id; ?>" type="button" class="btn btn-sm btn-default warning_1">Delete</a></h6>
 	 		</div>
 	 	</div>
 	 	<script type="text/javascript">
 	 		   $('.active_<?php echo $theme_id; ?>').click(function() {
var theme_iddd=$("#theme_idd<?php echo $theme_id; ?>").val();
 $.ajax({
      type:"post",
      url:"<?php echo $base_url; ?>/manage/theme_activate.php",
      data:"theme_iddd="+theme_iddd,
      success:function(y)
      {
      	//alert(y);
       if(y=='activated')
       {
       	window.location.reload();
       }
       // alert(y);
      }
    });

 	 		   });
 	 	</script>
 	 	<?php } ?>
 
 	 	
 	 	 <div class="clearfix"> </div>
 	 </div>
	<!--//gallery-->
		<!---->
<div class="copy">
            <p> &copy; 2017 Stenum Asia. All Rights Reserved  </p>   </div>
		</div>
		</div>
		<div class="clearfix"> </div>
       </div>
     
<!---->
<link rel="stylesheet" href="<?php echo $base_url; ?>assets/css/swipebox.css">
	<script src="<?php echo $base_url; ?>assets/js/jquery.swipebox.min.js"></script> 
	    <script type="text/javascript">
			jQuery(function($) {
				$(".swipebox").swipebox();
			});
</script>
<!--scrolling js-->
	<script src="<?php echo $base_url; ?>assets/js/jquery.nicescroll.js"></script>
	<script src="<?php echo $base_url; ?>assets/js/scripts.js"></script>
	<!--//scrolling js-->

</body>
</html>

