<?php
include('../config.php'); 
 $theme_iddd=$_POST['theme_iddd'];
 $sql_chk="update theme set status='' where status='Active'";
   $query_chk=$mysqli->query($sql_chk);


   $sql_theme_chk="update theme set status='Active' where id='$theme_iddd'";
   $query_theme_chk=$mysqli->query($sql_theme_chk);
   if($query_theme_chk)
   {
   	echo 'activated';
   }

 ?>