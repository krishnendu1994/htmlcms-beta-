<script type="text/javascript">
	window.location='pages.php';
</script>