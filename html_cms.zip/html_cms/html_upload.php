<?php 
include('config.php');
// function rmdir_recursive($dir) {
//     foreach(scandir($dir) as $file) {
//        if ('.' === $file || '..' === $file) continue;
//        if (is_dir("$dir/$file")) rmdir_recursive("$dir/$file");
//        else unlink("$dir/$file");
//    }

//    @rmdir($dir);
// }

if($_FILES["zip_file"]["name"]) {
    $filename = $_FILES["zip_file"]["name"];
    $source = $_FILES["zip_file"]["tmp_name"];
    $type = $_FILES["zip_file"]["type"];

    $name = explode(".", $filename);
    $accepted_types = array('application/zip', 'application/x-zip-compressed', 'multipart/x-zip', 'application/x-compressed');
    foreach($accepted_types as $mime_type) {
        if($mime_type == $type) {
            $okay = true;
            break;
        } 
    }

    $continue = strtolower($name[1]) == 'zip' ? true : false;
    if(!$continue) {
        $message = "The file you are trying to upload is not a .zip file. Please try again.";
    }

  /* PHP current path */
  $path = dirname(__FILE__).'/';  // absolute path to the directory where zipper.php is in
  $filenoext = basename ($filename, '.zip');  // absolute path to the directory where zipper.php is in (lowercase)
  $filenoext = basename ($filenoext, '.ZIP');  // absolute path to the directory where zipper.php is in (when uppercase)

  $targetdir = $path . 'themes/'; // target directory
  $targetzip = $path . $filename; // target zip file

  /* create directory if not exists', otherwise overwrite */
  /* target directory is same as filename without extension */

  //if (is_dir($targetdir))  rmdir_recursive ( $targetdir);


  @mkdir($targetdir, 0777);


  /* here it is really happening */

    if(move_uploaded_file($source, $targetzip)) {
        $zip = new ZipArchive();
        $x = $zip->open($targetzip);  // open the zip file to extract
        if ($x === true) {
            $zip->extractTo($targetdir); // place in the directory with same name  
            $zip->close();

            unlink($targetzip);
        }
        $message = "Your .zip file was uploaded and unpacked.";
    } else {    
        $message = "There was a problem with the upload. Please try again.";
    }
}
echo $message;
 $filenoext;

if($message=='Your .zip file was uploaded and unpacked.')
{
  $sql_chk="select * from theme where status='active'";
   $query_chk=$mysqli->query($sql_chk);
   $row_chk=$query_chk->fetch_array();
   //print_r($row_chk['status']);
 //  if()
  $sql="insert into `theme`(theme_name,status) values('$filenoext','Active')";
    $query=$mysqli->query($sql);
    if($query)
        {
          $theme_id=$mysqli->insert_id;
           // sql to create table
$sqls = "CREATE TABLE theme_body (
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
theme_id VARCHAR(250) NOT NULL,
page_name VARCHAR(250) NOT NULL,
page_content TEXT NOT NULL
)";

if ($mysqli->query($sqls) === TRUE) {
  
   
} else {
    
}
$sqls1 = "CREATE TABLE theme_header (
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
theme_id VARCHAR(250) NOT NULL,
header TEXT NOT NULL
)";

if ($mysqli->query($sqls1) === TRUE) {
  
   
} else {
    
}
$sqls2 = "CREATE TABLE theme_footer (
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
theme_id VARCHAR(250) NOT NULL,
footer TEXT NOT NULL
)";

if ($mysqli->query($sqls2) === TRUE) {
  
   
} else {
    
}
$sqls3 = "CREATE TABLE theme_script (
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
theme_id VARCHAR(250) NOT NULL,
script TEXT NOT NULL
)";

if ($mysqli->query($sqls3) === TRUE) {
  
   
} else {
    
}
$sqls4 = "CREATE TABLE theme_style (
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
theme_id VARCHAR(250) NOT NULL,
style TEXT NOT NULL
)";

if ($mysqli->query($sqls4) === TRUE) {
  
   
} else {
    
}

$sqls5 = "CREATE TABLE theme_page (
id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
theme_id VARCHAR(250) NOT NULL,
page_name TEXT NOT NULL
)";

if ($mysqli->query($sqls5) === TRUE) {
  
   
} else {
    
}

$sql_index="insert into `theme_page`( theme_id,page_name) values('$theme_id','index')";
    $query_index=$mysqli->query($sql_index);



$html = file_get_contents('themes/'.$filenoext.'/index.html');
$doc = new DOMDocument();
libxml_use_internal_errors(true);
$doc->loadHTML($html);
$finder = new DomXPath($doc);




$node = $finder->query("//header");
echo $theme_header=$doc->saveHTML($node->item(0));
$rtrtrtrtr=base64_encode($theme_header);
$sql_page_header="insert into `theme_header`( theme_id,header) values('$theme_id','$rtrtrtrtr')";
    $query_page_header=$mysqli->query($sql_page_header);
 $node_1 = $finder->query("//footer");
  $theme_footer=$doc->saveHTML($node_1->item(0));
$rtrtrtrtr1=base64_encode($theme_footer);

$sql_page_footer="insert into `theme_footer`( theme_id,footer) values('$theme_id','$rtrtrtrtr1')";
    $query_page_footer=$mysqli->query($sql_page_footer);

// $node_2 = $finder->query("//body");
// echo $theme_body_index=$doc->saveHTML($node_2->item(0));

 //htmlspecialchars($phpCode);











$links = $doc->getElementsByTagName('link');

//Iterate over the extracted links and display their URLs
$text1='';
foreach ($links as $link){
    //Extract and show the "href" attribute.
   
    $href=$link->getAttribute('href');
     $urlStr=$link->getAttribute('href');
    $parsed = parse_url($urlStr);
    
    if(@$parsed['scheme']!=null)
    {
        //print_r($parsed);
        $parsed['path']=$parsed['path'].'?';
        foreach ($parsed as $key => $value) {
            if($parsed['scheme']=='http' || $parsed['scheme']=='https')
            {
                $parsed['scheme']=$parsed['scheme'].'://';
            }
            // if($parsed['path']=='http' )
            // {
                
            //}
            // if($parsed[$key]!='scheme')
            // {
                 $rtyu[]=$parsed[$key];
            //}

            

        }
            $ttu=$rtyu;     //  $ttu=$rtyu; 
        //print_r($ttu);
        $ttu=implode('', $ttu);

    }
    else
    {
         $ttu='themes/'.$filenoext.'/'.$href; 
    }

  $ttu=base64_encode($ttu);
$yyyy=base64_decode($ttu);
    ?>
    <link rel="stylesheet" type="text/css" href="<?php echo $yyyy; ?>">

    <?php
        $sql_page_style="insert into `theme_style`( theme_id,style) values('$theme_id','$ttu')";
    $query_page_style=$mysqli->query($sql_page_style);


}

$rt='base2013/';
//$myfile = fopen("filename.php", "w") or die("Unable to open file!");
$links1 = $doc->getElementsByTagName('script');

//Iterate over the extracted links and display their URLs
$text1='';
foreach ($links1 as $link1){
    //Extract and show the "href" attribute.
   
    $href1=$link1->getAttribute('src');

   $ttu1='themes/'.$filenoext.'/'.$href1; 
   if($href1=='')
   {
    ?>
    <script type="text/javascript">
        <?php echo $sc_th=$link1->nodeValue, PHP_EOL;   $sql_page_script1="insert into `theme_script`( theme_id,script) values('$theme_id','$sc_th')";
    $query_page_script1=$mysqli->query($sql_page_script1); ?>
    </script>
    <?php
   }
   $ttu1=base64_encode($ttu1);
   $yyyy5=base64_decode($ttu1);
    $sql_page_script="insert into `theme_script`( theme_id,script) values('$theme_id','$ttu1')";
    $query_page_script=$mysqli->query($sql_page_script);
    ?>
   <!--  <link rel="stylesheet" type="text/css" href="<?php echo $ttu; ?>"> -->
   <script src="<?php echo $yyyy5; ?>"></script>
    <?php
}

for($c = 1; $a = $doc->getElementsByTagName('header')->item(0); $c++) {
    $a->parentNode->replaceChild(
        $doc->createTextNode(print_r(' ', $c)),
        $a
    );
}
for($cd = 1; $ad = $doc->getElementsByTagName('footer')->item(0); $cd++) {
    $ad->parentNode->replaceChild(
        $doc->createTextNode(print_r(' ', $cd)),
        $ad
    );
}
// for($cde = 1; $ade = $doc->getElementsByTagName('script')->item(0); $cde++) {
//     $ade->parentNode->removeChild(
//        $doc->getElementsByTagName('script')->item(0)
//     );
// }

// $doc->getElementsByTagName('body');
//  $theme_body_index=$doc->saveHTML();

$body = $doc->getElementsByTagName('html');
if ( $body && 0<$body->length ) {
    $body = $body->item(0);
   echo $theme_body_index=$doc->savehtml($body);
}


 $theme_body_index=base64_encode($theme_body_index);
  $sql_page_body="insert into `theme_body`( theme_id,page_name,page_content) values('$theme_id','index','".$theme_body_index."')";
    $query_page_body=$mysqli->query($sql_page_body);





        }   
}

//echo $theme_footer;
$dirs='themes/'.$filenoext.'/';
if (is_dir($dirs)) {
    if ($dh = opendir($dirs)) {
      $i=1;
        while (($file = readdir($dh)) !== false) {
           // echo "filename: .".$file."<br />";
          if($file!='index.html'){
             
              $info = new SplFileInfo($file);
           if($info->getExtension()=='html'){
 $file_name=$file;
echo $file_name."<br>";
 $page_name=$info->getBasename('.' .$info->getExtension());


$sql_page="insert into `theme_page`( theme_id,page_name) values('$theme_id','$page_name')";
    $query_page=$mysqli->query($sql_page);


$docx = new DOMDocument();
libxml_use_internal_errors(true);

$finderx = new DomXPath($docx);
 $htmlx = file_get_contents('themes/'.$filenoext.'/'.$file_name);


$docx->loadHTML($htmlx);
for($c = 1; $a = $docx->getElementsByTagName('header')->item(0); $c++) {
    $a->parentNode->replaceChild(
        $docx->createTextNode(print_r(' ', $c)),
        $a
    );
}
for($cd = 1; $ad = $docx->getElementsByTagName('footer')->item(0); $cd++) {
    $ad->parentNode->replaceChild(
        $docx->createTextNode(print_r(' ', $cd)),
        $ad
    );
}
// for($cdee = 1; $adee = $doc->getElementsByTagName('script')->item(0); $cdee++) {
//     $adee->parentNode->removeChild(
//        $docx->getElementsByTagName('script')->item(0)
//     );
// }
 // $theme_body_pages=$docx->saveHTML();

$body1 = $docx->getElementsByTagName('html');
if ( $body1 && 0<$body1->length ) {
    $body1 = $body1->item(0);
    $theme_body_pages=$docx->savehtml($body1);
}
  $theme_body_pages=base64_encode($theme_body_pages);

  $sql_page_body1="insert into `theme_body`( theme_id,page_name,page_content) values('$theme_id','$page_name','".$theme_body_pages."')";
    $query_page_body1=$mysqli->query($sql_page_body1);














$i++;
           } 
          }

            
        }
        closedir($dh);
    }
}

 if(@$query_page_body1)
 {
  ?>
  <script type="text/javascript">
    window.location='index.php';
  </script>
  <?php
 
 }
 if(@$query_page_body)
 {
  ?>
  <script type="text/javascript">
    window.location='index.php';
  </script>
  <?php
}

?>